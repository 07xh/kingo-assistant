# 青果选课辅助 Windows V4.6（独立只读版）

这是运行在 **Windows 10/11** 的独立桌面应用源码；不依赖 Android APK、校序 App 或云服务器。它沿用现有 Python 只读读取与调度核心。本项目**不是可直接抢课的成品**，没有自动选课提交；学校官方接口和登录流程仍待本人合法验证。

## 最快验证（不登录学校）

1. 解压 ZIP。电脑安装 **Python 3.10+** 后双击 `run-windows.bat`（第一次需要网络安装依赖）；它会打开桌面界面。
2. 连续点击三次 **“虚构样例：下一步”**，观察内置虚构课程的 `已满 → 发现余量（2）→ 已满`。演示不会联网、不接入学校，也不会把虚构数据存进你的课程配置。
3. 点击 **“检查配置”** 回到自己的本地课程列表。再使用“编辑课程和设置”修改课程代码、教学班、学期、只读监测间隔等；保存时从 YAML 删除 Cookie 和推送令牌。
4. 真正的学校课程监测需要学校允许访问的**官方只读接口**、本人合法会话和已核验的页面结构，默认全部拦截。点击“运行准备度”可以查看还有哪些前提未具备。

注意：点击“浏览器打开官方教务”只会使用默认浏览器打开官网，**不会把浏览器登录态自动复制给本程序**。

## 生成独立 EXE

Windows 电脑安装 Python 3.10+ 后双击 `build-windows.bat`，脚本依次执行：

- 新建或使用 `.venv`，安装依赖及 PyInstaller；
- 运行完整离线单元测试，执行源码 `--self-test`；
- 以 `--onefile --windowed` 模式打包主程序、配置模板和 `demo/` 资源；
- 由 `tools/verify_windows_build.py` 在 **Windows 原生环境**运行打包 EXE 的 `--self-test` 和 `--smoke-gui`；每项都有超时与退出码检查，失败时删除可能存在的旧 EXE；
- 生成 `dist\SHA256.txt` 和 `dist\build-verification.json`，分别保存哈希和明确标注的 Windows 打包验证结果。

也可把源码放进自己的独立 GitHub 仓库，运行 `.github/workflows/windows-build.yml` 中的手动工作流构建 Windows EXE。首次构建需要网络下载依赖，构建完成后 EXE 作为本机程序运行。**当前尚未进行原生 Windows 的 EXE 构建及实机验收**，GitHub 工作流不是已完成运行的证明。

如桌面版无法打开，可运行 `debug-windows.bat` 诊断 Python 源码模式。分享故障日志前请检查是否包含个人信息。

Windows 原生构建若成功，GitHub Actions 工件中应同时存在 EXE、SHA256.txt 和 build-verification.json。缺失报告、报告未标明 Windows、或任一离线检查未通过时，**不能标为 Windows 已验收**。

## 已完成

- 完全独立的 Windows Tk 桌面界面；课程查看、编辑、离线配置检查与运行准备度检查。
- 只读课程余量监测入口、启动/停止、查询次数与用时展示、余量变化提示与脱敏日志导出。
- 本地已脱敏 HTML 导入演练；内置三步**虚构**HTML 演练，无需自备样本。
- **离线工具→本机 HAR 结构检查**：仅从本人合法导出的 HAR 中统计华水 HTTPS 域名、请求方法、响应状态和 MIME 类型；不重放请求，不导出请求 URL、账号、Cookie、请求体或响应正文。该统计不代表 API 已核实。
- 发生错误时显示会话失效、学校访问限制、协议结构不符、网络失败、配置错误等**类别**，不输出服务器原文、身份标识或 Cookie。
- 运行期间不能修改配置；停止并退出时取消后台任务。
- 72 项本机离线单元测试、Linux Xvfb/Tk GUI 烟雾测试，以及源码 `--self-test`、`--smoke-gui` 通过。

## 尚未完成

- 原生 Windows 10/11 EXE 构建验证与应用启动验收（当前环境不具备 Windows 本机或已配置的独立 GitHub 构建仓库）；
- 华水真实只读接口、页面列序、余量来源、访问频率及合法登录会话联调；
- 自动提交选课（当前**不提供**）、校园服务器不可用时保证成功（任何软件都不能保证）。

## 本地配置与安全

- EXE 首次运行自动从包内 `config.example.yaml` 复制为 `%LOCALAPPDATA%\KingoAssistantReadOnly\config.yaml`，不覆盖用户已有配置；未打包源码会在用户主目录下建立 `.kingo-assistant-readonly` 目录（Windows 除外）。
- 默认 `protocol.verified: false`、`strategy.dry_run: true`。**不要把“已核实”标志当成真实接口通过验收**。
- 如学校允许，凭据仅通过进程环境变量 `KINGO_COOKIE` 传入；不鼓励将 Cookie 或密码写入 YAML、网盘、日志或 GitHub。
- 第三方通知需明确开启，敏感令牌优先走环境变量。仅在学校规定的请求频率内操作；遇到 403/429 立即停止，不规避验证码或限流。
- **“发现余量”不代表“选课成功”**，实际结果必须以学校教务平台为准。

开发与核心协议背景请阅读 `README.md`，本次更新见 `CHANGELOG-Windows-v4.6.md`。
